#ifndef __SRCSTATE_H__
#define __SRCSTATE_h__

typedef enum {
  LOGIN,
  REGISTER,
  RANK,
  FIGHT,
  MEET,
  LOGOUT,
  QUIT,
  BACK,
  HOME,
  SPEED,
  STRENGTH,
} ScreenState;

#endif